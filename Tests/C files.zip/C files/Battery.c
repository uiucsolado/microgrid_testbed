#include "C:\Users\zholbar1\Documents\microgrid_testbed\MST_MicroGrid\C files\Battery.h"

//float Tamb = 30;
//float Cnom = 1e3,Inom = 1;
//Cbat = 1.67*Cnom*(1+0.005*(Tamb-25))/(1+0.67*pow(abs(Ibat)/Inom,0.9))
float battery(float x)
{
    return 23.4;
}
