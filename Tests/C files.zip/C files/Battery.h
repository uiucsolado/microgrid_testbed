#ifndef Battery_h
#define Battery_h

float battery(float x);


#endif /* Battery_h */
